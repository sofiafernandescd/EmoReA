print ("If you are a new user of SDK, please check out https://github.com/Justin1904/CMU-MultimodalSDK-Tutorials - an amzing tutorial thanks to Zhun Liu @ Justin1904")
