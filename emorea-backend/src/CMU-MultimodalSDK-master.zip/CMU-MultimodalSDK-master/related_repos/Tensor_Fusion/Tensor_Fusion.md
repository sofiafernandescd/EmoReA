"Tensor Fusion Network for Multimodal Sentiment Analysis", Amir Zadeh, Minghai Chen, Soujanya Poria, Erik Cambria, Louis-Philippe Morency, EMNLP 2017. 
https://arxiv.org/pdf/1707.07250.pdf

Original version of Tensor Fusion Networks is implemented here: https://github.com/A2Zadeh/TensorFusionNetwork

Zhun Liu has a version implemented: https://github.com/Justin1904/TensorFusionNetworks

Zhun Liu and Ying Shen have a more parametric efficient model here: https://github.com/Justin1904/Low-rank-Multimodal-Fusion

  
