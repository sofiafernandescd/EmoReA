CMU Multimodal Opinion Sentiment and Emotion Intensity (CMU-MOSEI) is the largest dataset of sentence level sentiment analysis and emotion recognition in online videos. CMU-MOSEI contains more than 65 hours of annotated video from more than 1000 speakers and 250 topics. The dataset was introduced in the 2018 Association for Computational Linguistics 2018 and used in the co-located First Grand Challenge and Workshop on Human Multimodal Language. 

CMU-MOSEI has sentiment and 6 emotion scores for sentences in YouTube monologue videos. Multiple emotions can be present at a time. 
