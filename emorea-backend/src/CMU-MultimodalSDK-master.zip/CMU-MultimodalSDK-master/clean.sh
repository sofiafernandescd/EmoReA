find . -name "*.pyc" -type f -delete
find . -name "__pycache__" -type d -delete

