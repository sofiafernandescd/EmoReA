featuresetMetadataTemplate=	[
			"root name",#name of the featureset
			"computational sequence description",#name of the featureset
			"computational sequence version",#the version of featureset
			"alignment compatible",#name of the featureset
			"dataset name",#featureset belongs to which dataset
			"dataset version",#the version of dataset
			"creator",#the author of the featureset
			"contact",#the contact of the featureset
			"featureset bib citation",#citation for the paper related to this featureset
			"dataset bib citation"#citation for the dataset
			]



